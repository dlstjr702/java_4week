package days17;

public class Student {  
	
	// 필드
	public int no;	// 학번
	public String name;
	public int kor, eng, mat, tot, rank, wrank;
	public double avg;
	
	// 메소드
	public String getInfo() {
		return String.format("[%d]\t%s\t%d\t%d\t%d\t%d\t%.2f\t%d\t%d"
				, no
				, name 
				, kor , eng , mat, tot 
				, avg , rank, wrank);
	}

	/*
	@Override
	public String toString() {
		return "Student [no=" + no + ", name=" + name + ", kor=" + kor + ", eng=" + eng + ", mat=" + mat + ", tot="
				+ tot + ", rank=" + rank + ", wrank=" + wrank + ", avg=" + avg + "]";
	}
	*/
	

} // class

/*
+----------------+
|   Student      |
+----------------+
| name           |
| kor            |
| eng            |
| math           |
| total          |
| avg            |
| rank           |
+----------------+
| calcTotal()    |
| calcAvg()      |
+----------------+
        ▲
        |
        |

+--------------------+   학생들 리스트 관리 클래스
|  StudentManager    |
+--------------------+
| List<Student>      |   Student [] students; 배열
+--------------------+
| addStudent()       |   학생 정보 입력()
| printStudents()    |   학생 정보 출력()
| processRank()      |   등수 처리 ()
+--------------------+
*/
