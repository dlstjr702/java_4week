package days17;

import java.util.HashSet;

/**
 * @author kenik
 * @date 2026. 6. 4. 오후 3:43:15
 * @subject C -> L : ArrayList, Vector, LinkedList
 * @content C -> S : HashSet 컬렉션 클래스
 *               ㄴ 순서유지X, 중복허용X 
 * 
 */
public class Ex11 {

	public static void main(String[] args) {
		HashSet hs = new HashSet(); // 16, 0.75
		hs.add(9);
		hs.add(1);
		hs.add(15);
		
		System.out.println( hs ); // [1, 9, 15]   순서 유지 X
		
		hs.add(1);
		hs.add(1);
		hs.add(1);

		System.out.println( hs ); // [1, 9, 15]   중복 허용 X
		
		hs.add(null);
		hs.add(null);
		hs.add(null);
		
		System.out.println( hs ); // [1, 9, 15]   중복 허용 X
				
		hs.remove(1);
		
	} // main

} // class




