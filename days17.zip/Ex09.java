package days17;

import java.util.Enumeration;
import java.util.Vector;

/**
 * @author kenik
 * @date 2026. 6. 4. 오후 2:52:46
 * @subject [Vector 컬렉션 클래스]
 * @content C -> L -> ArrayList 컬렉션 클래스
 *                    Vector 컬렉션 클래스 ( 차이점: 멀티 스레드 안전 )
 * 
 */
public class Ex09 {

	public static void main(String[] args) {
		Vector v = new Vector(3);  // 10
		System.out.println( v.size() ); // 요소 갯수 0
		System.out.println( v.capacity() ); // 초기 용량 10
		
		v.addElement("양인석");
		v.add("안정빈");
		v.add("신창만");		
		System.out.println( v.size() ); // 요소 갯수 3		
        v.add("이지훈");		
		System.out.println( v.capacity() ); // 요소 갯수 6
		
		System.out.println(  v.get(0) );
		System.out.println(  v.getFirst() );
		System.out.println(  v.elementAt(0) );

		// 모든 요소 출력.  반복자,열거자
		Enumeration  en = v.elements();
		while (en.hasMoreElements()) { //  요소 가지고 있니? true/false
			String name = (String) en.nextElement(); // 
			System.out.println( name );
		}
		
		// 마지막 요소 
		int lastIndex = v.size() - 1;
		System.out.println( v.get( lastIndex ));
		System.out.println( v.lastElement());
		
		v.remove(0);
		v.remove("안정빈");
		
		
	} // main

} // class





