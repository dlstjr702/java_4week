package days17;

import java.util.Stack;

/**
 * @author kenik
 * @date 2026. 6. 4. 오후 5:17:54
 * @subject  C -> L : ArrayList, Vector, LinkedList
 * @content  C -> S : HashSet, LinkedHashSet
 * 
 *           [ Stack 컬렉션 클래스 ]
 *             ㄴ LIFO 자료구조
 *              ------------
 *     <-               2 1 |
 *              ------------
 *              
 *              Stack -> Vector -> List
 *                       멀티스레드 안전(동기화 처리)
 *                       ArrayList 
 */
public class Ex12 {

	public static void main(String[] args) {
		Stack s = new Stack();
//		s.add(s);              X
//		s.addElement(s);       X     
//		s.addFirst(s);         X
		s.push("양인석");
		s.push("안정빈");
		s.push("신창만");
		s.push("이지훈");
		
		System.out.println( s.size());
		
		// s.get(2);
		// System.out.println( s.pop() ); 
		System.out.println( s.peek() );
		
		System.out.println( s.size());
		
		System.out.println( s.search("서주원")  ); // -1
		System.out.println( s.search("안정빈")  ); // 3
		
	    System.out.println( s.isEmpty());
	    
	    // push(), pop()/peek(), isEmpty(), search()

	    while (  !s.isEmpty()  ) {
			System.out.println( s.pop() ); 
		} // while
	    
	} // main

} // class



